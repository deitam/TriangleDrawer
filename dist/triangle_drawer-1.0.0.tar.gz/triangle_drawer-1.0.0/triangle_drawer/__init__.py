"""A package to draw any triangle on screen."""
__version__ = '1.0.0'
from .triangle import Triangle
